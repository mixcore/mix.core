Upload folder to store files from user;s upload files.
